## PLEASE READ!

# **WARNING** (Don't do this!)

1. Don't change the name of file

2. Don't change the name of title Example: play_loading: //< == don't change and remove!

3. Don't remove the message has start with %{example} and don't do anything!

4. Go read 1.

# **HOW TO MAKE ANOTHER LANGUAGES!**

1. Goto `languages` folder

2. Create `folder` language if you want Example `th`

3. Goto `languages/en` CTRL + A AND CTRL + C

4. back to u folder on create and CTRL + V

5. `Right Click` edit and done!

6. You can edit if you want but please read warning first!
