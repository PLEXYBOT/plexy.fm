const MainClient = require("./nanospace");
const client = new MainClient();

client.connect()

module.exports = client; 